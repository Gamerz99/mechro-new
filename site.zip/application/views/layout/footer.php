<style>
    .footer{
        background-image: url("<?php echo base_url(); ?>images/footer1.jpg");
        opacity: 1;

    }
</style>
<div class=" footer mbr-parallax-background" >
    <!-- ################################################################################################ -->
    <div class="wrapper row4">
        <footer id="footer" class="hoc clear">
            <!-- ################################################################################################ -->

            <div class="col-md-3 first">
                <h6 class="heading">Navigation</h6>
                <ul class="nospace linklist">
                    <li><a href="<?php echo base_url(); ?>index.php/home">Home</a></li>
                    <li><a href="<?php echo base_url(); ?>index.php/about">About Us</a></li>
                    <li><a href="<?php echo base_url(); ?>index.php/gallery">Gallery</a></li>
                    <li><a href="<?php echo base_url(); ?>index.php/contact">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-md-6 text-center">
                <h6 class="heading "> Contact Us</h6>
                <ul class="nospace btmspace-30 linklist ">
                    <li><i class="fa fa-map-marker"></i>
                        No 135/1/1, Elliot Road, Galle
                    </li>
                    <li><i class="fa fa-phone"></i> +94 0714864007 / +940770083907</li>
                    <li><i class="fa fa-envelope-o"> </i> <a href="mailto:mechrocom@gmail.com">mechrocom@gmail.com</a></li>
                </ul>
                <ul class="faico clear ">
                    <li><a class="faicon-facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a class="faicon-twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a class="faicon-dribble" href="#"><i class="fa fa-dribbble"></i></a></li>
                    <li><a class="faicon-linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
            </div>
            <div class="col-md-3 text-right">
                <h6 class="heading"> Support</h6>
                <ul class="nospace btmspace-30 linklist contact">
                    <li><a href="<?php echo base_url(); ?>index.php/contact">Google Map</a></li>
                    <li> <a  href="<?php echo base_url(); ?>index.php/admin"><span class="glyphicon glyphicon-share"></span></a></li>
                </ul>

            </div>
            <!-- ################################################################################################ -->
        </footer>
    </div>
    <div class="wrapper row5">
        <div id="copyright" class="hoc clear">
            <!-- ################################################################################################ -->
            <p class="fl_center">Copyright &copy; 2018 @ MECH-RO Associate (PVT) LTD </p>
            <!-- ################################################################################################ -->
        </div>
    </div>
    <!-- ################################################################################################ -->
</div>
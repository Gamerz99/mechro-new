<!DOCTYPE html>
<head>
    <title>MECH-RO Associated PVT LTD </title>
    <meta name="description" content="Mec hro Associated PVT LTD is machinery company in sri lanka, we build machinery for factory, house. also we do do constructions">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="icon" href="images/preview.png">
    <link rel="stylesheet" href="<?php echo base_url(); ?>styles/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>styles/magnific-popup.css">

    <link href="<?php echo base_url(); ?>styles/layout.css" rel="stylesheet" type="text/css" media="all">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <style>
        .main1{
            background-image: url("<?php echo base_url(); ?>images/intro2.jpg");
            opacity: 1;
        }
        .divider1{
            background-image: url("<?php echo base_url(); ?>images/home2.jpg");
            opacity: 1;
        }

        .divider2{
            background-image: url("<?php echo base_url(); ?>images/home1.jpg");
            opacity: 1;
        }
    </style>
</head>
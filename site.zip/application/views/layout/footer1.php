<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.1.0
    </div>
    <strong>Copyright &copy; 2018     All rights
        reserved.
</footer>
</div>
<script src="<?php echo base_url(); ?>layout/bower_components/jquery/dist/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>layout/bower_components/jquery-ui/jquery-ui.min.js"></script>
<script>
    $.widget.bridge('uibutton', $.ui.button);
</script>
<script src="<?php echo base_url(); ?>layout/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>layout/bower_components/raphael/raphael.min.js"></script>
<script src="<?php echo base_url(); ?>layout/bower_components/morris.js/morris.min.js"></script>
<script src="<?php echo base_url(); ?>layout/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url(); ?>layout/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo base_url(); ?>layout/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="<?php echo base_url(); ?>layout/bower_components/jquery-knob/dist/jquery.knob.min.js"></script>
<script src="<?php echo base_url(); ?>layout/bower_components/moment/min/moment.min.js"></script>
<script src="<?php echo base_url(); ?>layout/bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url(); ?>layout/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script src="<?php echo base_url(); ?>layout/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script src="<?php echo base_url(); ?>layout/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url(); ?>layout/bower_components/fastclick/lib/fastclick.js"></script>
<script src="<?php echo base_url(); ?>layout/dist/js/adminlte.min.js"></script>
<script src="<?php echo base_url(); ?>layout/dist/js/pages/dashboard.js"></script>
<script src="<?php echo base_url(); ?>layout/dist/js/demo.js"></script>
</body>
</html>

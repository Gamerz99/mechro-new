window.addEventListener("load",function () {
    var load_screen=document.getElementById("loading1");
    document.body.removeChild(load_screen);
});

$(document).ready(function(){
    $(".load").fadeIn(500);
});
